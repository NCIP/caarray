function  WWHBookData_MatchTopic(P)
{
var C=null;
if(P=="register_user_help")C="Getting%20Started%20caArray.3.8.html#1237205";
if(P=="add_group_help")C="User%20Account%20Mgt.9.10.html#1139979";
if(P=="group_details_help")C="User%20Account%20Mgt.9.11.html#1077437";
if(P=="modify_group_details_help")C="User%20Account%20Mgt.9.12.html#1087125";
return C;
}
