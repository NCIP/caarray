---------------------------------------------------------------------
README for the fix_raw_derived_relationships script
released with caArray 2.2.0
---------------------------------------------------------------------

The issue:
----------
Data that was imported via MAGE-TAB before caArray 2.1.0 has an issue
where derived data files are not associated with the corresponding
raw data files.

The solution:
-------------
A SQL script is provided to scrub pre-2.1.0 data to correct raw-derived
data relationships. Please run the fix_raw_derived_relationships.sql
script against your caarray database.

It is highly recommended that you run this script, since otherwise,
the MAGE-TAB export of some of your pre-2.1.0 experiments can be
incorrect. To be precise, the SDRF file generated (via the "Export
Consolidated MAGE-TAB" button) can have duplicate rows - one with the
raw data file and the second with the derived data file.

Details of what the script does:
--------------------------------
The SQL script looks for hybridizations that:
1. have exactly one raw data file; and
2. have one or more derived data files; and
3. one or more of those derived data files are unassociated to any raw data file.
For each such derived data file, the script adds the raw data
file to its "derived_from" set.

---------------------------------------------------------------------
