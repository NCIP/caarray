package org.apache.jsp.tag.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class action_tag
    extends javax.servlet.jsp.tagext.SimpleTagSupport
    implements org.apache.jasper.runtime.JspSourceDependent {


  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/WEB-INF/tags/linkButton.tag");
  }

  private JspContext jspContext;
  private java.io.Writer _jspx_sout;
  public void setJspContext(JspContext ctx) {
    super.setJspContext(ctx);
    java.util.ArrayList _jspx_nested = null;
    java.util.ArrayList _jspx_at_begin = null;
    java.util.ArrayList _jspx_at_end = null;
    this.jspContext = new org.apache.jasper.runtime.JspContextWrapper(ctx, _jspx_nested, _jspx_at_begin, _jspx_at_end, null);
  }

  public JspContext getJspContext() {
    return this.jspContext;
  }
  private java.lang.String onclick;
  private java.lang.String url;
  private java.lang.String actionClass;
  private java.lang.String text;
  private java.lang.String tabindex;

  public java.lang.String getOnclick() {
    return this.onclick;
  }

  public void setOnclick(java.lang.String onclick) {
    this.onclick = onclick;
  }

  public java.lang.String getUrl() {
    return this.url;
  }

  public void setUrl(java.lang.String url) {
    this.url = url;
  }

  public java.lang.String getActionClass() {
    return this.actionClass;
  }

  public void setActionClass(java.lang.String actionClass) {
    this.actionClass = actionClass;
  }

  public java.lang.String getText() {
    return this.text;
  }

  public void setText(java.lang.String text) {
    this.text = text;
  }

  public java.lang.String getTabindex() {
    return this.tabindex;
  }

  public void setTabindex(java.lang.String tabindex) {
    this.tabindex = tabindex;
  }

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void doTag() throws JspException, java.io.IOException {
    PageContext _jspx_page_context = (PageContext)jspContext;
    HttpServletRequest request = (HttpServletRequest) _jspx_page_context.getRequest();
    HttpServletResponse response = (HttpServletResponse) _jspx_page_context.getResponse();
    HttpSession session = _jspx_page_context.getSession();
    ServletContext application = _jspx_page_context.getServletContext();
    ServletConfig config = _jspx_page_context.getServletConfig();
    JspWriter out = jspContext.getOut();
    if( getOnclick() != null ) 
      _jspx_page_context.setAttribute("onclick", getOnclick());
    if( getUrl() != null ) 
      _jspx_page_context.setAttribute("url", getUrl());
    if( getActionClass() != null ) 
      _jspx_page_context.setAttribute("actionClass", getActionClass());
    if( getText() != null ) 
      _jspx_page_context.setAttribute("text", getText());
    if( getTabindex() != null ) 
      _jspx_page_context.setAttribute("tabindex", getTabindex());

    try {
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<li>");
      if (_jspx_meth_caarray_linkButton_0(_jspx_page_context))
        return;
      out.write("</li>");
    } catch( Throwable t ) {
      if( t instanceof SkipPageException )
          throw (SkipPageException) t;
      if( t instanceof java.io.IOException )
          throw (java.io.IOException) t;
      if( t instanceof IllegalStateException )
          throw (IllegalStateException) t;
      if( t instanceof JspException )
          throw (JspException) t;
      throw new JspException(t);
    } finally {
      ((org.apache.jasper.runtime.JspContextWrapper) jspContext).syncEndTagFile();
    }
  }

  private boolean _jspx_meth_caarray_linkButton_0(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  caarray:linkButton
    org.apache.jsp.tag.web.linkButton_tag _jspx_th_caarray_linkButton_0 = new org.apache.jsp.tag.web.linkButton_tag();
    _jspx_th_caarray_linkButton_0.setJspContext(_jspx_page_context);
    _jspx_th_caarray_linkButton_0.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) this ));    _jspx_th_caarray_linkButton_0.setActionClass((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${actionClass}", java.lang.String.class, (PageContext)this.getJspContext(), null, false));
    _jspx_th_caarray_linkButton_0.setText((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${text}", java.lang.String.class, (PageContext)this.getJspContext(), null, false));
    _jspx_th_caarray_linkButton_0.setUrl((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${url}", java.lang.String.class, (PageContext)this.getJspContext(), null, false));
    _jspx_th_caarray_linkButton_0.setTabindex((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tabindex}", java.lang.String.class, (PageContext)this.getJspContext(), null, false));
    _jspx_th_caarray_linkButton_0.setOnclick((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${onclick}", java.lang.String.class, (PageContext)this.getJspContext(), null, false));
    _jspx_th_caarray_linkButton_0.doTag();
    return false;
  }
}
