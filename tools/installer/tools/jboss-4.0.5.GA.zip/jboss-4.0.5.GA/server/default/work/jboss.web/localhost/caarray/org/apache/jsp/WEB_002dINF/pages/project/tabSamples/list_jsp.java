package org.apache.jsp.WEB_002dINF.pages.project.tabSamples;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class list_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(10);
    _jspx_dependants.add("/WEB-INF/pages/common/taglibs.jsp");
    _jspx_dependants.add("/WEB-INF/tags/projectListTabCommon.tagf");
    _jspx_dependants.add("/WEB-INF/tags/tabPane.tag");
    _jspx_dependants.add("/WEB-INF/tags/successMessages.tag");
    _jspx_dependants.add("/WEB-INF/tags/projectListTabHeader.tag");
    _jspx_dependants.add("/WEB-INF/tags/projectListTabActionLink.tag");
    _jspx_dependants.add("/WEB-INF/tags/linkButton.tag");
    _jspx_dependants.add("/WEB-INF/tags/displayTagProperties.tag");
    _jspx_dependants.add("/WEB-INF/tags/projectListTabRelatedItemsLinks.tag");
    _jspx_dependants.add("/WEB-INF/tags/projectListTabHiddenForm.tag");
  }

  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_c_set_var;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_fmt_message_key_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_c_url_var_value;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_c_param_value_name_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_ajax_displayTag_tableClass_id_ajaxFlag;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_display_table_sort_requestURI_pagesize_list_id_excludedParams_defaultsort_class_cellspacing;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_display_column_titleKey_sortable;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_display_column_titleKey_sortable_property_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_display_column_titleKey;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_ajax_anchors_target;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_c_url_value_nobody;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _jspx_tagPool_c_set_var = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_fmt_message_key_nobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_c_url_var_value = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_c_param_value_name_nobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_ajax_displayTag_tableClass_id_ajaxFlag = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_display_table_sort_requestURI_pagesize_list_id_excludedParams_defaultsort_class_cellspacing = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_display_column_titleKey_sortable = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_display_column_titleKey_sortable_property_nobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_display_column_titleKey = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_ajax_anchors_target = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_c_url_value_nobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
  }

  public void _jspDestroy() {
    _jspx_tagPool_c_set_var.release();
    _jspx_tagPool_fmt_message_key_nobody.release();
    _jspx_tagPool_c_url_var_value.release();
    _jspx_tagPool_c_param_value_name_nobody.release();
    _jspx_tagPool_ajax_displayTag_tableClass_id_ajaxFlag.release();
    _jspx_tagPool_display_table_sort_requestURI_pagesize_list_id_excludedParams_defaultsort_class_cellspacing.release();
    _jspx_tagPool_display_column_titleKey_sortable.release();
    _jspx_tagPool_display_column_titleKey_sortable_property_nobody.release();
    _jspx_tagPool_display_column_titleKey.release();
    _jspx_tagPool_ajax_anchors_target.release();
    _jspx_tagPool_c_url_value_nobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=utf-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"/error.jsp", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\n");
      if (_jspx_meth_c_set_0(_jspx_page_context))
        return;
      out.write("\r\n");
      out.write("\r\n");
      //  caarray:tabPane
      org.apache.jsp.tag.web.tabPane_tag _jspx_th_caarray_tabPane_0 = new org.apache.jsp.tag.web.tabPane_tag();
      _jspx_th_caarray_tabPane_0.setJspContext(_jspx_page_context);
      _jspx_th_caarray_tabPane_0.setSubtab("true");
      _jspx_th_caarray_tabPane_0.setJspBody(new list_jspHelper( 0, _jspx_page_context, _jspx_th_caarray_tabPane_0, null));
      _jspx_th_caarray_tabPane_0.doTag();
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_c_set_0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:set
    org.apache.taglibs.standard.tag.rt.core.SetTag _jspx_th_c_set_0 = (org.apache.taglibs.standard.tag.rt.core.SetTag) _jspx_tagPool_c_set_var.get(org.apache.taglibs.standard.tag.rt.core.SetTag.class);
    _jspx_th_c_set_0.setPageContext(_jspx_page_context);
    _jspx_th_c_set_0.setParent(null);
    _jspx_th_c_set_0.setVar("datePattern");
    int _jspx_eval_c_set_0 = _jspx_th_c_set_0.doStartTag();
    if (_jspx_eval_c_set_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_c_set_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_c_set_0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_c_set_0.doInitBody();
      }
      do {
        if (_jspx_meth_fmt_message_0(_jspx_th_c_set_0, _jspx_page_context))
          return true;
        int evalDoAfterBody = _jspx_th_c_set_0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_c_set_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_c_set_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_c_set_var.reuse(_jspx_th_c_set_0);
      return true;
    }
    _jspx_tagPool_c_set_var.reuse(_jspx_th_c_set_0);
    return false;
  }

  private boolean _jspx_meth_fmt_message_0(javax.servlet.jsp.tagext.JspTag _jspx_th_c_set_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  fmt:message
    org.apache.taglibs.standard.tag.rt.fmt.MessageTag _jspx_th_fmt_message_0 = (org.apache.taglibs.standard.tag.rt.fmt.MessageTag) _jspx_tagPool_fmt_message_key_nobody.get(org.apache.taglibs.standard.tag.rt.fmt.MessageTag.class);
    _jspx_th_fmt_message_0.setPageContext(_jspx_page_context);
    _jspx_th_fmt_message_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_c_set_0);
    _jspx_th_fmt_message_0.setKey("date.format");
    int _jspx_eval_fmt_message_0 = _jspx_th_fmt_message_0.doStartTag();
    if (_jspx_th_fmt_message_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_fmt_message_key_nobody.reuse(_jspx_th_fmt_message_0);
      return true;
    }
    _jspx_tagPool_fmt_message_key_nobody.reuse(_jspx_th_fmt_message_0);
    return false;
  }

  private boolean _jspx_meth_caarray_projectListTabHeader_0(javax.servlet.jsp.tagext.JspTag _jspx_parent, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  caarray:projectListTabHeader
    org.apache.jsp.tag.web.projectListTabHeader_tag _jspx_th_caarray_projectListTabHeader_0 = new org.apache.jsp.tag.web.projectListTabHeader_tag();
    _jspx_th_caarray_projectListTabHeader_0.setJspContext(_jspx_page_context);
    _jspx_th_caarray_projectListTabHeader_0.setParent(_jspx_parent);
    _jspx_th_caarray_projectListTabHeader_0.setEntityName("Sample");
    _jspx_th_caarray_projectListTabHeader_0.setIsSubtab("true");
    _jspx_th_caarray_projectListTabHeader_0.doTag();
    return false;
  }

  private boolean _jspx_meth_c_url_0(javax.servlet.jsp.tagext.JspTag _jspx_parent, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_url_0 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _jspx_tagPool_c_url_var_value.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_url_0.setPageContext(_jspx_page_context);
    _jspx_th_c_url_0.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) _jspx_parent));
    _jspx_th_c_url_0.setValue("/protected/ajax/project/listTab/Sample/load.action");
    _jspx_th_c_url_0.setVar("sortUrl");
    int _jspx_eval_c_url_0 = _jspx_th_c_url_0.doStartTag();
    if (_jspx_eval_c_url_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_c_url_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_c_url_0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_c_url_0.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("        ");
        if (_jspx_meth_c_param_0(_jspx_th_c_url_0, _jspx_page_context))
          return true;
        out.write("\r\n");
        out.write("    ");
        int evalDoAfterBody = _jspx_th_c_url_0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_c_url_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_c_url_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_c_url_var_value.reuse(_jspx_th_c_url_0);
      throw new SkipPageException();
    }
    _jspx_tagPool_c_url_var_value.reuse(_jspx_th_c_url_0);
    return false;
  }

  private boolean _jspx_meth_c_param_0(javax.servlet.jsp.tagext.JspTag _jspx_th_c_url_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:param
    org.apache.taglibs.standard.tag.rt.core.ParamTag _jspx_th_c_param_0 = (org.apache.taglibs.standard.tag.rt.core.ParamTag) _jspx_tagPool_c_param_value_name_nobody.get(org.apache.taglibs.standard.tag.rt.core.ParamTag.class);
    _jspx_th_c_param_0.setPageContext(_jspx_page_context);
    _jspx_th_c_param_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_c_url_0);
    _jspx_th_c_param_0.setName("project.id");
    _jspx_th_c_param_0.setValue((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${project.id}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_param_0 = _jspx_th_c_param_0.doStartTag();
    if (_jspx_th_c_param_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_c_param_value_name_nobody.reuse(_jspx_th_c_param_0);
      throw new SkipPageException();
    }
    _jspx_tagPool_c_param_value_name_nobody.reuse(_jspx_th_c_param_0);
    return false;
  }

  private boolean _jspx_meth_caarray_displayTagProperties_0(javax.servlet.jsp.tagext.JspTag _jspx_th_display_table_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  caarray:displayTagProperties
    org.apache.jsp.tag.web.displayTagProperties_tag _jspx_th_caarray_displayTagProperties_0 = new org.apache.jsp.tag.web.displayTagProperties_tag();
    _jspx_th_caarray_displayTagProperties_0.setJspContext(_jspx_page_context);
    _jspx_th_caarray_displayTagProperties_0.setParent(_jspx_th_display_table_0);
    _jspx_th_caarray_displayTagProperties_0.doTag();
    return false;
  }

  private boolean _jspx_meth_display_column_1(javax.servlet.jsp.tagext.JspTag _jspx_th_display_table_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  display:column
    org.displaytag.tags.ColumnTag _jspx_th_display_column_1 = (org.displaytag.tags.ColumnTag) _jspx_tagPool_display_column_titleKey_sortable_property_nobody.get(org.displaytag.tags.ColumnTag.class);
    _jspx_th_display_column_1.setPageContext(_jspx_page_context);
    _jspx_th_display_column_1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_table_0);
    _jspx_th_display_column_1.setProperty("description");
    _jspx_th_display_column_1.setTitleKey("experiment.samples.description");
    _jspx_th_display_column_1.setSortable(true);
    int _jspx_eval_display_column_1 = _jspx_th_display_column_1.doStartTag();
    if (_jspx_th_display_column_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_column_titleKey_sortable_property_nobody.reuse(_jspx_th_display_column_1);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_column_titleKey_sortable_property_nobody.reuse(_jspx_th_display_column_1);
    return false;
  }

  private boolean _jspx_meth_display_column_2(javax.servlet.jsp.tagext.JspTag _jspx_th_display_table_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  display:column
    org.displaytag.tags.ColumnTag _jspx_th_display_column_2 = (org.displaytag.tags.ColumnTag) _jspx_tagPool_display_column_titleKey_sortable_property_nobody.get(org.displaytag.tags.ColumnTag.class);
    _jspx_th_display_column_2.setPageContext(_jspx_page_context);
    _jspx_th_display_column_2.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_table_0);
    _jspx_th_display_column_2.setProperty("organism.commonName");
    _jspx_th_display_column_2.setTitleKey("experiment.samples.organism");
    _jspx_th_display_column_2.setSortable(true);
    int _jspx_eval_display_column_2 = _jspx_th_display_column_2.doStartTag();
    if (_jspx_th_display_column_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_column_titleKey_sortable_property_nobody.reuse(_jspx_th_display_column_2);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_column_titleKey_sortable_property_nobody.reuse(_jspx_th_display_column_2);
    return false;
  }

  private boolean _jspx_meth_display_column_3(javax.servlet.jsp.tagext.JspTag _jspx_th_display_table_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  display:column
    org.displaytag.tags.ColumnTag _jspx_th_display_column_3 = (org.displaytag.tags.ColumnTag) _jspx_tagPool_display_column_titleKey.get(org.displaytag.tags.ColumnTag.class);
    _jspx_th_display_column_3.setPageContext(_jspx_page_context);
    _jspx_th_display_column_3.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_table_0);
    _jspx_th_display_column_3.setTitleKey("experiment.samples.tissueSite");
    int _jspx_eval_display_column_3 = _jspx_th_display_column_3.doStartTag();
    if (_jspx_eval_display_column_3 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_column_3 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_column_3.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_column_3.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("                ");
        out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${!empty row.tissueSite ? row.tissueSite.name : 'No Tissue Site'}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
        out.write("\r\n");
        out.write("            ");
        int evalDoAfterBody = _jspx_th_display_column_3.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_column_3 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_column_3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_3);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_3);
    return false;
  }

  private boolean _jspx_meth_display_column_4(javax.servlet.jsp.tagext.JspTag _jspx_th_display_table_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  display:column
    org.displaytag.tags.ColumnTag _jspx_th_display_column_4 = (org.displaytag.tags.ColumnTag) _jspx_tagPool_display_column_titleKey.get(org.displaytag.tags.ColumnTag.class);
    _jspx_th_display_column_4.setPageContext(_jspx_page_context);
    _jspx_th_display_column_4.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_table_0);
    _jspx_th_display_column_4.setTitleKey("experiment.samples.sources");
    int _jspx_eval_display_column_4 = _jspx_th_display_column_4.doStartTag();
    if (_jspx_eval_display_column_4 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_column_4 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_column_4.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_column_4.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("                ");
        if (_jspx_meth_caarray_projectListTabRelatedItemsLinks_0(_jspx_th_display_column_4, _jspx_page_context))
          return true;
        out.write("\r\n");
        out.write("            ");
        int evalDoAfterBody = _jspx_th_display_column_4.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_column_4 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_column_4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_4);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_4);
    return false;
  }

  private boolean _jspx_meth_caarray_projectListTabRelatedItemsLinks_0(javax.servlet.jsp.tagext.JspTag _jspx_th_display_column_4, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  caarray:projectListTabRelatedItemsLinks
    org.apache.jsp.tag.web.projectListTabRelatedItemsLinks_tag _jspx_th_caarray_projectListTabRelatedItemsLinks_0 = new org.apache.jsp.tag.web.projectListTabRelatedItemsLinks_tag();
    _jspx_th_caarray_projectListTabRelatedItemsLinks_0.setJspContext(_jspx_page_context);
    _jspx_th_caarray_projectListTabRelatedItemsLinks_0.setParent(_jspx_th_display_column_4);
    _jspx_th_caarray_projectListTabRelatedItemsLinks_0.setRelatedItems((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${row.sources}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    _jspx_th_caarray_projectListTabRelatedItemsLinks_0.setRelatedEntityName("Source");
    _jspx_th_caarray_projectListTabRelatedItemsLinks_0.setNameProperty("name");
    _jspx_th_caarray_projectListTabRelatedItemsLinks_0.setIsSubtab("true");
    _jspx_th_caarray_projectListTabRelatedItemsLinks_0.doTag();
    return false;
  }

  private boolean _jspx_meth_display_column_5(javax.servlet.jsp.tagext.JspTag _jspx_th_display_table_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  display:column
    org.displaytag.tags.ColumnTag _jspx_th_display_column_5 = (org.displaytag.tags.ColumnTag) _jspx_tagPool_display_column_titleKey.get(org.displaytag.tags.ColumnTag.class);
    _jspx_th_display_column_5.setPageContext(_jspx_page_context);
    _jspx_th_display_column_5.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_table_0);
    _jspx_th_display_column_5.setTitleKey("experiment.samples.extracts");
    int _jspx_eval_display_column_5 = _jspx_th_display_column_5.doStartTag();
    if (_jspx_eval_display_column_5 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_column_5 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_column_5.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_column_5.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("                ");
        if (_jspx_meth_caarray_projectListTabRelatedItemsLinks_1(_jspx_th_display_column_5, _jspx_page_context))
          return true;
        out.write("\r\n");
        out.write("            ");
        int evalDoAfterBody = _jspx_th_display_column_5.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_column_5 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_column_5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_5);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_5);
    return false;
  }

  private boolean _jspx_meth_caarray_projectListTabRelatedItemsLinks_1(javax.servlet.jsp.tagext.JspTag _jspx_th_display_column_5, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  caarray:projectListTabRelatedItemsLinks
    org.apache.jsp.tag.web.projectListTabRelatedItemsLinks_tag _jspx_th_caarray_projectListTabRelatedItemsLinks_1 = new org.apache.jsp.tag.web.projectListTabRelatedItemsLinks_tag();
    _jspx_th_caarray_projectListTabRelatedItemsLinks_1.setJspContext(_jspx_page_context);
    _jspx_th_caarray_projectListTabRelatedItemsLinks_1.setParent(_jspx_th_display_column_5);
    _jspx_th_caarray_projectListTabRelatedItemsLinks_1.setRelatedItems((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${row.extracts}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    _jspx_th_caarray_projectListTabRelatedItemsLinks_1.setRelatedEntityName("Extract");
    _jspx_th_caarray_projectListTabRelatedItemsLinks_1.setNameProperty("name");
    _jspx_th_caarray_projectListTabRelatedItemsLinks_1.setIsSubtab("true");
    _jspx_th_caarray_projectListTabRelatedItemsLinks_1.doTag();
    return false;
  }

  private boolean _jspx_meth_display_column_7(javax.servlet.jsp.tagext.JspTag _jspx_th_display_table_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  display:column
    org.displaytag.tags.ColumnTag _jspx_th_display_column_7 = (org.displaytag.tags.ColumnTag) _jspx_tagPool_display_column_titleKey.get(org.displaytag.tags.ColumnTag.class);
    _jspx_th_display_column_7.setPageContext(_jspx_page_context);
    _jspx_th_display_column_7.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_table_0);
    _jspx_th_display_column_7.setTitleKey("button.download");
    int _jspx_eval_display_column_7 = _jspx_th_display_column_7.doStartTag();
    if (_jspx_eval_display_column_7 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_column_7 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_column_7.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_column_7.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("                ");
        if (_jspx_meth_ajax_anchors_0(_jspx_th_display_column_7, _jspx_page_context))
          return true;
        out.write("\r\n");
        out.write("            ");
        int evalDoAfterBody = _jspx_th_display_column_7.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_column_7 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_column_7.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_7);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_7);
    return false;
  }

  private boolean _jspx_meth_ajax_anchors_0(javax.servlet.jsp.tagext.JspTag _jspx_th_display_column_7, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  ajax:anchors
    org.ajaxtags.tags.AjaxAnchorsTag _jspx_th_ajax_anchors_0 = (org.ajaxtags.tags.AjaxAnchorsTag) _jspx_tagPool_ajax_anchors_target.get(org.ajaxtags.tags.AjaxAnchorsTag.class);
    _jspx_th_ajax_anchors_0.setPageContext(_jspx_page_context);
    _jspx_th_ajax_anchors_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_column_7);
    _jspx_th_ajax_anchors_0.setTarget("tabboxlevel2wrapper");
    int _jspx_eval_ajax_anchors_0 = _jspx_th_ajax_anchors_0.doStartTag();
    if (_jspx_eval_ajax_anchors_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_ajax_anchors_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_ajax_anchors_0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_ajax_anchors_0.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("                    <a href=\"");
        if (_jspx_meth_c_url_1(_jspx_th_ajax_anchors_0, _jspx_page_context))
          return true;
        out.write("\"><img src=\"");
        if (_jspx_meth_c_url_2(_jspx_th_ajax_anchors_0, _jspx_page_context))
          return true;
        out.write("\" alt=\"");
        if (_jspx_meth_fmt_message_1(_jspx_th_ajax_anchors_0, _jspx_page_context))
          return true;
        out.write("\" /></a>\r\n");
        out.write("                ");
        int evalDoAfterBody = _jspx_th_ajax_anchors_0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_ajax_anchors_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_ajax_anchors_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_ajax_anchors_target.reuse(_jspx_th_ajax_anchors_0);
      throw new SkipPageException();
    }
    _jspx_tagPool_ajax_anchors_target.reuse(_jspx_th_ajax_anchors_0);
    return false;
  }

  private boolean _jspx_meth_c_url_1(javax.servlet.jsp.tagext.JspTag _jspx_th_ajax_anchors_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_url_1 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _jspx_tagPool_c_url_value_nobody.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_url_1.setPageContext(_jspx_page_context);
    _jspx_th_c_url_1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_ajax_anchors_0);
    _jspx_th_c_url_1.setValue("/ajax/notYetImplemented.jsp");
    int _jspx_eval_c_url_1 = _jspx_th_c_url_1.doStartTag();
    if (_jspx_th_c_url_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_c_url_value_nobody.reuse(_jspx_th_c_url_1);
      throw new SkipPageException();
    }
    _jspx_tagPool_c_url_value_nobody.reuse(_jspx_th_c_url_1);
    return false;
  }

  private boolean _jspx_meth_c_url_2(javax.servlet.jsp.tagext.JspTag _jspx_th_ajax_anchors_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_url_2 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _jspx_tagPool_c_url_value_nobody.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_url_2.setPageContext(_jspx_page_context);
    _jspx_th_c_url_2.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_ajax_anchors_0);
    _jspx_th_c_url_2.setValue("/images/ico_download.gif");
    int _jspx_eval_c_url_2 = _jspx_th_c_url_2.doStartTag();
    if (_jspx_th_c_url_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_c_url_value_nobody.reuse(_jspx_th_c_url_2);
      throw new SkipPageException();
    }
    _jspx_tagPool_c_url_value_nobody.reuse(_jspx_th_c_url_2);
    return false;
  }

  private boolean _jspx_meth_fmt_message_1(javax.servlet.jsp.tagext.JspTag _jspx_th_ajax_anchors_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  fmt:message
    org.apache.taglibs.standard.tag.rt.fmt.MessageTag _jspx_th_fmt_message_1 = (org.apache.taglibs.standard.tag.rt.fmt.MessageTag) _jspx_tagPool_fmt_message_key_nobody.get(org.apache.taglibs.standard.tag.rt.fmt.MessageTag.class);
    _jspx_th_fmt_message_1.setPageContext(_jspx_page_context);
    _jspx_th_fmt_message_1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_ajax_anchors_0);
    _jspx_th_fmt_message_1.setKey("button.download");
    int _jspx_eval_fmt_message_1 = _jspx_th_fmt_message_1.doStartTag();
    if (_jspx_th_fmt_message_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_fmt_message_key_nobody.reuse(_jspx_th_fmt_message_1);
      throw new SkipPageException();
    }
    _jspx_tagPool_fmt_message_key_nobody.reuse(_jspx_th_fmt_message_1);
    return false;
  }

  private boolean _jspx_meth_caarray_projectListTabHiddenForm_0(javax.servlet.jsp.tagext.JspTag _jspx_parent, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  caarray:projectListTabHiddenForm
    org.apache.jsp.tag.web.projectListTabHiddenForm_tag _jspx_th_caarray_projectListTabHiddenForm_0 = new org.apache.jsp.tag.web.projectListTabHiddenForm_tag();
    _jspx_th_caarray_projectListTabHiddenForm_0.setJspContext(_jspx_page_context);
    _jspx_th_caarray_projectListTabHiddenForm_0.setParent(_jspx_parent);
    _jspx_th_caarray_projectListTabHiddenForm_0.setEntityName("Sample");
    _jspx_th_caarray_projectListTabHiddenForm_0.setIsSubtab("true");
    _jspx_th_caarray_projectListTabHiddenForm_0.doTag();
    return false;
  }

  private class list_jspHelper
      extends org.apache.jasper.runtime.JspFragmentHelper
  {
    private javax.servlet.jsp.tagext.JspTag _jspx_parent;
    private int[] _jspx_push_body_count;

    public list_jspHelper( int discriminator, JspContext jspContext, javax.servlet.jsp.tagext.JspTag _jspx_parent, int[] _jspx_push_body_count ) {
      super( discriminator, jspContext, _jspx_parent );
      this._jspx_parent = _jspx_parent;
      this._jspx_push_body_count = _jspx_push_body_count;
    }
    public void invoke0( JspWriter out ) 
      throws Throwable
    {
      out.write("\r\n");
      out.write("    ");
      if (_jspx_meth_caarray_projectListTabHeader_0(_jspx_parent, _jspx_page_context))
        return;
      out.write("\r\n");
      out.write("    \r\n");
      out.write("    ");
      if (_jspx_meth_c_url_0(_jspx_parent, _jspx_page_context))
        return;
      out.write("\r\n");
      out.write("\r\n");
      out.write("    <div class=\"tableboxpad\">\r\n");
      out.write("    ");
      //  ajax:displayTag
      org.ajaxtags.tags.AjaxDisplayTag _jspx_th_ajax_displayTag_0 = (org.ajaxtags.tags.AjaxDisplayTag) _jspx_tagPool_ajax_displayTag_tableClass_id_ajaxFlag.get(org.ajaxtags.tags.AjaxDisplayTag.class);
      _jspx_th_ajax_displayTag_0.setPageContext(_jspx_page_context);
      _jspx_th_ajax_displayTag_0.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) _jspx_parent));
      _jspx_th_ajax_displayTag_0.setId("datatable");
      _jspx_th_ajax_displayTag_0.setAjaxFlag("true");
      _jspx_th_ajax_displayTag_0.setTableClass("searchresults");
      int _jspx_eval_ajax_displayTag_0 = _jspx_th_ajax_displayTag_0.doStartTag();
      if (_jspx_eval_ajax_displayTag_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        if (_jspx_eval_ajax_displayTag_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
          out = _jspx_page_context.pushBody();
          _jspx_th_ajax_displayTag_0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
          _jspx_th_ajax_displayTag_0.doInitBody();
        }
        do {
          out.write("\r\n");
          out.write("        ");
          //  display:table
          org.displaytag.tags.TableTag _jspx_th_display_table_0 = (org.displaytag.tags.TableTag) _jspx_tagPool_display_table_sort_requestURI_pagesize_list_id_excludedParams_defaultsort_class_cellspacing.get(org.displaytag.tags.TableTag.class);
          _jspx_th_display_table_0.setPageContext(_jspx_page_context);
          _jspx_th_display_table_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_ajax_displayTag_0);
          _jspx_th_display_table_0.setClass("searchresults");
          _jspx_th_display_table_0.setCellspacing("0");
          _jspx_th_display_table_0.setDefaultsort(1);
          _jspx_th_display_table_0.setList((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${project.experiment.samples}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
          _jspx_th_display_table_0.setRequestURI((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${sortUrl}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
          _jspx_th_display_table_0.setSort("list");
          _jspx_th_display_table_0.setUid("row");
          _jspx_th_display_table_0.setPagesize(20);
          _jspx_th_display_table_0.setExcludedParams("project.id");
          int _jspx_eval_display_table_0 = _jspx_th_display_table_0.doStartTag();
          if (_jspx_eval_display_table_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            java.lang.Object row = null;
            java.lang.Integer row_rowNum = null;
            if (_jspx_eval_display_table_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
              out = _jspx_page_context.pushBody();
              _jspx_th_display_table_0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
              _jspx_th_display_table_0.doInitBody();
            }
            row = (java.lang.Object) _jspx_page_context.findAttribute("row");
            row_rowNum = (java.lang.Integer) _jspx_page_context.findAttribute("row_rowNum");
            do {
              out.write("\r\n");
              out.write("            ");
              if (_jspx_meth_caarray_displayTagProperties_0(_jspx_th_display_table_0, _jspx_page_context))
                return;
              out.write("\r\n");
              out.write("            ");
              //  display:column
              org.displaytag.tags.ColumnTag _jspx_th_display_column_0 = (org.displaytag.tags.ColumnTag) _jspx_tagPool_display_column_titleKey_sortable.get(org.displaytag.tags.ColumnTag.class);
              _jspx_th_display_column_0.setPageContext(_jspx_page_context);
              _jspx_th_display_column_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_table_0);
              _jspx_th_display_column_0.setTitleKey("experiment.samples.name");
              _jspx_th_display_column_0.setSortable(true);
              int _jspx_eval_display_column_0 = _jspx_th_display_column_0.doStartTag();
              if (_jspx_eval_display_column_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                if (_jspx_eval_display_column_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
                  out = _jspx_page_context.pushBody();
                  _jspx_th_display_column_0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
                  _jspx_th_display_column_0.doInitBody();
                }
                do {
                  out.write("\r\n");
                  out.write("                ");
                  //  caarray:projectListTabActionLink
                  org.apache.jsp.tag.web.projectListTabActionLink_tag _jspx_th_caarray_projectListTabActionLink_0 = new org.apache.jsp.tag.web.projectListTabActionLink_tag();
                  _jspx_th_caarray_projectListTabActionLink_0.setJspContext(_jspx_page_context);
                  _jspx_th_caarray_projectListTabActionLink_0.setParent(_jspx_th_display_column_0);
                  _jspx_th_caarray_projectListTabActionLink_0.setLinkContent((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${row.name}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
                  _jspx_th_caarray_projectListTabActionLink_0.setEntityName("Sample");
                  _jspx_th_caarray_projectListTabActionLink_0.setAction("view");
                  _jspx_th_caarray_projectListTabActionLink_0.setItemId((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${row.id}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
                  _jspx_th_caarray_projectListTabActionLink_0.setIsSubtab("true");
                  _jspx_th_caarray_projectListTabActionLink_0.doTag();
                  out.write("\r\n");
                  out.write("            ");
                  int evalDoAfterBody = _jspx_th_display_column_0.doAfterBody();
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
                if (_jspx_eval_display_column_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
                  out = _jspx_page_context.popBody();
                }
              }
              if (_jspx_th_display_column_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
                _jspx_tagPool_display_column_titleKey_sortable.reuse(_jspx_th_display_column_0);
                throw new SkipPageException();
              }
              _jspx_tagPool_display_column_titleKey_sortable.reuse(_jspx_th_display_column_0);
              out.write("\r\n");
              out.write("            ");
              if (_jspx_meth_display_column_1(_jspx_th_display_table_0, _jspx_page_context))
                return;
              out.write("\r\n");
              out.write("            ");
              if (_jspx_meth_display_column_2(_jspx_th_display_table_0, _jspx_page_context))
                return;
              out.write("\r\n");
              out.write("            ");
              if (_jspx_meth_display_column_3(_jspx_th_display_table_0, _jspx_page_context))
                return;
              out.write("\r\n");
              out.write("            ");
              if (_jspx_meth_display_column_4(_jspx_th_display_table_0, _jspx_page_context))
                return;
              out.write("\r\n");
              out.write("            ");
              if (_jspx_meth_display_column_5(_jspx_th_display_table_0, _jspx_page_context))
                return;
              out.write("\r\n");
              out.write("            ");
              //  display:column
              org.displaytag.tags.ColumnTag _jspx_th_display_column_6 = (org.displaytag.tags.ColumnTag) _jspx_tagPool_display_column_titleKey.get(org.displaytag.tags.ColumnTag.class);
              _jspx_th_display_column_6.setPageContext(_jspx_page_context);
              _jspx_th_display_column_6.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_table_0);
              _jspx_th_display_column_6.setTitleKey("button.edit");
              int _jspx_eval_display_column_6 = _jspx_th_display_column_6.doStartTag();
              if (_jspx_eval_display_column_6 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                if (_jspx_eval_display_column_6 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
                  out = _jspx_page_context.pushBody();
                  _jspx_th_display_column_6.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
                  _jspx_th_display_column_6.doInitBody();
                }
                do {
                  out.write("\r\n");
                  out.write("                ");
                  //  caarray:projectListTabActionLink
                  org.apache.jsp.tag.web.projectListTabActionLink_tag _jspx_th_caarray_projectListTabActionLink_1 = new org.apache.jsp.tag.web.projectListTabActionLink_tag();
                  _jspx_th_caarray_projectListTabActionLink_1.setJspContext(_jspx_page_context);
                  _jspx_th_caarray_projectListTabActionLink_1.setParent(_jspx_th_display_column_6);
                  _jspx_th_caarray_projectListTabActionLink_1.setEntityName("Sample");
                  _jspx_th_caarray_projectListTabActionLink_1.setAction("edit");
                  _jspx_th_caarray_projectListTabActionLink_1.setItemId((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${row.id}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
                  _jspx_th_caarray_projectListTabActionLink_1.setIsSubtab("true");
                  _jspx_th_caarray_projectListTabActionLink_1.doTag();
                  out.write("\r\n");
                  out.write("            ");
                  int evalDoAfterBody = _jspx_th_display_column_6.doAfterBody();
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
                if (_jspx_eval_display_column_6 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
                  out = _jspx_page_context.popBody();
                }
              }
              if (_jspx_th_display_column_6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
                _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_6);
                throw new SkipPageException();
              }
              _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_6);
              out.write("\r\n");
              out.write("            ");
              if (_jspx_meth_display_column_7(_jspx_th_display_table_0, _jspx_page_context))
                return;
              out.write("\r\n");
              out.write("            ");
              //  display:column
              org.displaytag.tags.ColumnTag _jspx_th_display_column_8 = (org.displaytag.tags.ColumnTag) _jspx_tagPool_display_column_titleKey.get(org.displaytag.tags.ColumnTag.class);
              _jspx_th_display_column_8.setPageContext(_jspx_page_context);
              _jspx_th_display_column_8.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_table_0);
              _jspx_th_display_column_8.setTitleKey("button.copy");
              int _jspx_eval_display_column_8 = _jspx_th_display_column_8.doStartTag();
              if (_jspx_eval_display_column_8 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                if (_jspx_eval_display_column_8 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
                  out = _jspx_page_context.pushBody();
                  _jspx_th_display_column_8.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
                  _jspx_th_display_column_8.doInitBody();
                }
                do {
                  out.write("\r\n");
                  out.write("                ");
                  //  caarray:projectListTabActionLink
                  org.apache.jsp.tag.web.projectListTabActionLink_tag _jspx_th_caarray_projectListTabActionLink_2 = new org.apache.jsp.tag.web.projectListTabActionLink_tag();
                  _jspx_th_caarray_projectListTabActionLink_2.setJspContext(_jspx_page_context);
                  _jspx_th_caarray_projectListTabActionLink_2.setParent(_jspx_th_display_column_8);
                  _jspx_th_caarray_projectListTabActionLink_2.setEntityName("Sample");
                  _jspx_th_caarray_projectListTabActionLink_2.setAction("copy");
                  _jspx_th_caarray_projectListTabActionLink_2.setItemId((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${row.id}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
                  _jspx_th_caarray_projectListTabActionLink_2.setIsSubtab("true");
                  _jspx_th_caarray_projectListTabActionLink_2.doTag();
                  out.write("\r\n");
                  out.write("            ");
                  int evalDoAfterBody = _jspx_th_display_column_8.doAfterBody();
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
                if (_jspx_eval_display_column_8 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
                  out = _jspx_page_context.popBody();
                }
              }
              if (_jspx_th_display_column_8.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
                _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_8);
                throw new SkipPageException();
              }
              _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_8);
              out.write("\r\n");
              out.write("            ");
              //  display:column
              org.displaytag.tags.ColumnTag _jspx_th_display_column_9 = (org.displaytag.tags.ColumnTag) _jspx_tagPool_display_column_titleKey.get(org.displaytag.tags.ColumnTag.class);
              _jspx_th_display_column_9.setPageContext(_jspx_page_context);
              _jspx_th_display_column_9.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_display_table_0);
              _jspx_th_display_column_9.setTitleKey("button.delete");
              int _jspx_eval_display_column_9 = _jspx_th_display_column_9.doStartTag();
              if (_jspx_eval_display_column_9 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                if (_jspx_eval_display_column_9 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
                  out = _jspx_page_context.pushBody();
                  _jspx_th_display_column_9.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
                  _jspx_th_display_column_9.doInitBody();
                }
                do {
                  out.write("\r\n");
                  out.write("                ");
                  //  caarray:projectListTabActionLink
                  org.apache.jsp.tag.web.projectListTabActionLink_tag _jspx_th_caarray_projectListTabActionLink_3 = new org.apache.jsp.tag.web.projectListTabActionLink_tag();
                  _jspx_th_caarray_projectListTabActionLink_3.setJspContext(_jspx_page_context);
                  _jspx_th_caarray_projectListTabActionLink_3.setParent(_jspx_th_display_column_9);
                  _jspx_th_caarray_projectListTabActionLink_3.setEntityName("Sample");
                  _jspx_th_caarray_projectListTabActionLink_3.setAction("delete");
                  _jspx_th_caarray_projectListTabActionLink_3.setItemId((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${row.id}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
                  _jspx_th_caarray_projectListTabActionLink_3.setIsSubtab("true");
                  _jspx_th_caarray_projectListTabActionLink_3.doTag();
                  out.write("            \r\n");
                  out.write("            ");
                  int evalDoAfterBody = _jspx_th_display_column_9.doAfterBody();
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
                if (_jspx_eval_display_column_9 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
                  out = _jspx_page_context.popBody();
                }
              }
              if (_jspx_th_display_column_9.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
                _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_9);
                throw new SkipPageException();
              }
              _jspx_tagPool_display_column_titleKey.reuse(_jspx_th_display_column_9);
              out.write("\r\n");
              out.write("        ");
              int evalDoAfterBody = _jspx_th_display_table_0.doAfterBody();
              row = (java.lang.Object) _jspx_page_context.findAttribute("row");
              row_rowNum = (java.lang.Integer) _jspx_page_context.findAttribute("row_rowNum");
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
            if (_jspx_eval_display_table_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
              out = _jspx_page_context.popBody();
            }
          }
          if (_jspx_th_display_table_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _jspx_tagPool_display_table_sort_requestURI_pagesize_list_id_excludedParams_defaultsort_class_cellspacing.reuse(_jspx_th_display_table_0);
            throw new SkipPageException();
          }
          _jspx_tagPool_display_table_sort_requestURI_pagesize_list_id_excludedParams_defaultsort_class_cellspacing.reuse(_jspx_th_display_table_0);
          out.write("\r\n");
          out.write("    ");
          int evalDoAfterBody = _jspx_th_ajax_displayTag_0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
        if (_jspx_eval_ajax_displayTag_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
          out = _jspx_page_context.popBody();
        }
      }
      if (_jspx_th_ajax_displayTag_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
        _jspx_tagPool_ajax_displayTag_tableClass_id_ajaxFlag.reuse(_jspx_th_ajax_displayTag_0);
        throw new SkipPageException();
      }
      _jspx_tagPool_ajax_displayTag_tableClass_id_ajaxFlag.reuse(_jspx_th_ajax_displayTag_0);
      out.write("\r\n");
      out.write("\r\n");
      out.write("    ");
      if (_jspx_meth_caarray_projectListTabHiddenForm_0(_jspx_parent, _jspx_page_context))
        return;
      out.write("\r\n");
      out.write("\r\n");
      out.write("    </div>\r\n");
      return;
    }
    public void invoke( java.io.Writer writer )
      throws JspException
    {
      JspWriter out = null;
      if( writer != null ) {
        out = this.jspContext.pushBody(writer);
      } else {
        out = this.jspContext.getOut();
      }
      try {
        switch( this.discriminator ) {
          case 0:
            invoke0( out );
            break;
        }
      }
      catch( Throwable e ) {
        if (e instanceof SkipPageException)
            throw (SkipPageException) e;
        throw new JspException( e );
      }
      finally {
        if( writer != null ) {
          this.jspContext.popBody();
        }
      }
    }
  }
}
