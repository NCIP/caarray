package org.apache.jsp.common;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class leftnav_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<div id=\"leftnav\">\r\n");
      out.write("    <ul class=\"caarraymenu\">\r\n");
      out.write("        <li class=\"liheader\">Public Pages</li>\r\n");
      out.write("        <li><a href=\"./\" class=\"selected\">Home</a></li>\r\n");
      out.write("        <li><a href=\"register.htm\">Register</a></li>\r\n");
      out.write("        <li><a href=\"login.htm\">Login</a></li>\r\n");
      out.write("        <li class=\"liheader\">caArray Software</li>\r\n");
      out.write("        <li><a href=\"about.htm\">What is caArray?</a></li>\r\n");
      out.write("        <li><a href=\"install.htm\">Install caArray</a></li>\r\n");
      out.write("        <li><a href=\"userguide.htm\">User Guide</a></li>\r\n");
      out.write("        <li><a href=\"releasenotes.htm\">Release Notes</a></li>\r\n");
      out.write("        <li><a href=\"techdocs.htm\">Technical Documentation</a></li>\r\n");
      out.write("    </ul>\r\n");
      out.write("    <ul class=\"quicklinks\">\r\n");
      out.write("        <li class=\"liheader\">Global Quick Links</li>\r\n");
      out.write("        <li><a href=\"http://www.cancer.gov/\" class=\"external\">National Cancer Institute (NCI)</a></li>\r\n");
      out.write("        <li><a href=\"http://ncicb.nci.nih.gov/\" class=\"external\">NCI Center for Bioinformatics (NCICB)</a></li>\r\n");
      out.write("        <li><a href=\"https://cabig.nci.nih.gov/\" class=\"external\">caBIG&trade; - Cancer Biomedical Informatics Grid&trade;</a></li>\r\n");
      out.write("    </ul>\r\n");
      out.write("</div>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
