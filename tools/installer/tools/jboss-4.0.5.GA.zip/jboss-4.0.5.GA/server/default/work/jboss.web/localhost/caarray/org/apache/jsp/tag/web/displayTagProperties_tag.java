package org.apache.jsp.tag.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class displayTagProperties_tag
    extends javax.servlet.jsp.tagext.SimpleTagSupport
    implements org.apache.jasper.runtime.JspSourceDependent {


  private static java.util.List _jspx_dependants;

  private JspContext jspContext;
  private java.io.Writer _jspx_sout;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_display_setProperty_value_name_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_display_setProperty_name;

  public void setJspContext(JspContext ctx) {
    super.setJspContext(ctx);
    java.util.ArrayList _jspx_nested = null;
    java.util.ArrayList _jspx_at_begin = null;
    java.util.ArrayList _jspx_at_end = null;
    this.jspContext = new org.apache.jasper.runtime.JspContextWrapper(ctx, _jspx_nested, _jspx_at_begin, _jspx_at_end, null);
  }

  public JspContext getJspContext() {
    return this.jspContext;
  }

  public Object getDependants() {
    return _jspx_dependants;
  }

  private void _jspInit(ServletConfig config) {
    _jspx_tagPool_display_setProperty_value_name_nobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(config);
    _jspx_tagPool_display_setProperty_name = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(config);
  }

  public void _jspDestroy() {
    _jspx_tagPool_display_setProperty_value_name_nobody.release();
    _jspx_tagPool_display_setProperty_name.release();
  }

  public void doTag() throws JspException, java.io.IOException {
    PageContext _jspx_page_context = (PageContext)jspContext;
    HttpServletRequest request = (HttpServletRequest) _jspx_page_context.getRequest();
    HttpServletResponse response = (HttpServletResponse) _jspx_page_context.getResponse();
    HttpSession session = _jspx_page_context.getSession();
    ServletContext application = _jspx_page_context.getServletContext();
    ServletConfig config = _jspx_page_context.getServletConfig();
    JspWriter out = jspContext.getOut();
    _jspInit(config);

    try {
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      if (_jspx_meth_display_setProperty_0(_jspx_page_context))
        return;
      out.write('\r');
      out.write('\n');
      if (_jspx_meth_display_setProperty_1(_jspx_page_context))
        return;
      out.write('\r');
      out.write('\n');
      if (_jspx_meth_display_setProperty_2(_jspx_page_context))
        return;
      out.write('\r');
      out.write('\n');
      if (_jspx_meth_display_setProperty_3(_jspx_page_context))
        return;
      out.write('\r');
      out.write('\n');
      if (_jspx_meth_display_setProperty_4(_jspx_page_context))
        return;
      out.write('\r');
      out.write('\n');
      if (_jspx_meth_display_setProperty_5(_jspx_page_context))
        return;
      out.write('\r');
      out.write('\n');
      if (_jspx_meth_display_setProperty_6(_jspx_page_context))
        return;
      out.write('\r');
      out.write('\n');
      if (_jspx_meth_display_setProperty_7(_jspx_page_context))
        return;
      out.write('\r');
      out.write('\n');
      if (_jspx_meth_display_setProperty_8(_jspx_page_context))
        return;
    } catch( Throwable t ) {
      if( t instanceof SkipPageException )
          throw (SkipPageException) t;
      if( t instanceof java.io.IOException )
          throw (java.io.IOException) t;
      if( t instanceof IllegalStateException )
          throw (IllegalStateException) t;
      if( t instanceof JspException )
          throw (JspException) t;
      throw new JspException(t);
    } finally {
      ((org.apache.jasper.runtime.JspContextWrapper) jspContext).syncEndTagFile();
      _jspDestroy();
    }
  }

  private boolean _jspx_meth_display_setProperty_0(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  display:setProperty
    org.displaytag.tags.SetPropertyTag _jspx_th_display_setProperty_0 = (org.displaytag.tags.SetPropertyTag) _jspx_tagPool_display_setProperty_value_name_nobody.get(org.displaytag.tags.SetPropertyTag.class);
    _jspx_th_display_setProperty_0.setPageContext(_jspx_page_context);
    _jspx_th_display_setProperty_0.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) this ));    _jspx_th_display_setProperty_0.setName("basic.empty.showtable");
    _jspx_th_display_setProperty_0.setValue("true");
    int _jspx_eval_display_setProperty_0 = _jspx_th_display_setProperty_0.doStartTag();
    if (_jspx_th_display_setProperty_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_setProperty_value_name_nobody.reuse(_jspx_th_display_setProperty_0);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_setProperty_value_name_nobody.reuse(_jspx_th_display_setProperty_0);
    return false;
  }

  private boolean _jspx_meth_display_setProperty_1(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  display:setProperty
    org.displaytag.tags.SetPropertyTag _jspx_th_display_setProperty_1 = (org.displaytag.tags.SetPropertyTag) _jspx_tagPool_display_setProperty_name.get(org.displaytag.tags.SetPropertyTag.class);
    _jspx_th_display_setProperty_1.setPageContext(_jspx_page_context);
    _jspx_th_display_setProperty_1.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) this ));    _jspx_th_display_setProperty_1.setName("paging.banner.no_items_found");
    int _jspx_eval_display_setProperty_1 = _jspx_th_display_setProperty_1.doStartTag();
    if (_jspx_eval_display_setProperty_1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_setProperty_1 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_setProperty_1.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_setProperty_1.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("    <div class=\"pagingtop\"><span class=\"pagebanner\">No {0} found.</span>\r\n");
        int evalDoAfterBody = _jspx_th_display_setProperty_1.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_setProperty_1 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_setProperty_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_1);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_1);
    return false;
  }

  private boolean _jspx_meth_display_setProperty_2(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  display:setProperty
    org.displaytag.tags.SetPropertyTag _jspx_th_display_setProperty_2 = (org.displaytag.tags.SetPropertyTag) _jspx_tagPool_display_setProperty_name.get(org.displaytag.tags.SetPropertyTag.class);
    _jspx_th_display_setProperty_2.setPageContext(_jspx_page_context);
    _jspx_th_display_setProperty_2.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) this ));    _jspx_th_display_setProperty_2.setName("paging.banner.one_item_found");
    int _jspx_eval_display_setProperty_2 = _jspx_th_display_setProperty_2.doStartTag();
    if (_jspx_eval_display_setProperty_2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_setProperty_2 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_setProperty_2.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_setProperty_2.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("    <div class=\"pagingtop\"><span class=\"pagebanner\">One {0} found.</span>\r\n");
        int evalDoAfterBody = _jspx_th_display_setProperty_2.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_setProperty_2 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_setProperty_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_2);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_2);
    return false;
  }

  private boolean _jspx_meth_display_setProperty_3(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  display:setProperty
    org.displaytag.tags.SetPropertyTag _jspx_th_display_setProperty_3 = (org.displaytag.tags.SetPropertyTag) _jspx_tagPool_display_setProperty_name.get(org.displaytag.tags.SetPropertyTag.class);
    _jspx_th_display_setProperty_3.setPageContext(_jspx_page_context);
    _jspx_th_display_setProperty_3.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) this ));    _jspx_th_display_setProperty_3.setName("paging.banner.all_items_found");
    int _jspx_eval_display_setProperty_3 = _jspx_th_display_setProperty_3.doStartTag();
    if (_jspx_eval_display_setProperty_3 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_setProperty_3 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_setProperty_3.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_setProperty_3.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("    <div class=\"pagingtop\"><span class=\"pagebanner\">{0} {1} found, displaying all {2}.</span>\r\n");
        int evalDoAfterBody = _jspx_th_display_setProperty_3.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_setProperty_3 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_setProperty_3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_3);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_3);
    return false;
  }

  private boolean _jspx_meth_display_setProperty_4(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  display:setProperty
    org.displaytag.tags.SetPropertyTag _jspx_th_display_setProperty_4 = (org.displaytag.tags.SetPropertyTag) _jspx_tagPool_display_setProperty_name.get(org.displaytag.tags.SetPropertyTag.class);
    _jspx_th_display_setProperty_4.setPageContext(_jspx_page_context);
    _jspx_th_display_setProperty_4.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) this ));    _jspx_th_display_setProperty_4.setName("paging.banner.some_items_found");
    int _jspx_eval_display_setProperty_4 = _jspx_th_display_setProperty_4.doStartTag();
    if (_jspx_eval_display_setProperty_4 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_setProperty_4 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_setProperty_4.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_setProperty_4.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("    <div class=\"pagingtop\"><span class=\"pagebanner\">{0} {1} found, displaying {2} to {3}.</span>\r\n");
        int evalDoAfterBody = _jspx_th_display_setProperty_4.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_setProperty_4 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_setProperty_4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_4);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_4);
    return false;
  }

  private boolean _jspx_meth_display_setProperty_5(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  display:setProperty
    org.displaytag.tags.SetPropertyTag _jspx_th_display_setProperty_5 = (org.displaytag.tags.SetPropertyTag) _jspx_tagPool_display_setProperty_name.get(org.displaytag.tags.SetPropertyTag.class);
    _jspx_th_display_setProperty_5.setPageContext(_jspx_page_context);
    _jspx_th_display_setProperty_5.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) this ));    _jspx_th_display_setProperty_5.setName("paging.banner.full");
    int _jspx_eval_display_setProperty_5 = _jspx_th_display_setProperty_5.doStartTag();
    if (_jspx_eval_display_setProperty_5 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_setProperty_5 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_setProperty_5.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_setProperty_5.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("    <span class=\"pagelinks\">[<a href=\"{1}\">First</a>/<a href=\"{2}\">Prev</a>]{0}[<a href=\"{3}\">Next</a>/<a href=\"{4}\">Last</a>]</span></div>\r\n");
        int evalDoAfterBody = _jspx_th_display_setProperty_5.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_setProperty_5 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_setProperty_5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_5);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_5);
    return false;
  }

  private boolean _jspx_meth_display_setProperty_6(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  display:setProperty
    org.displaytag.tags.SetPropertyTag _jspx_th_display_setProperty_6 = (org.displaytag.tags.SetPropertyTag) _jspx_tagPool_display_setProperty_name.get(org.displaytag.tags.SetPropertyTag.class);
    _jspx_th_display_setProperty_6.setPageContext(_jspx_page_context);
    _jspx_th_display_setProperty_6.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) this ));    _jspx_th_display_setProperty_6.setName("paging.banner.first");
    int _jspx_eval_display_setProperty_6 = _jspx_th_display_setProperty_6.doStartTag();
    if (_jspx_eval_display_setProperty_6 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_setProperty_6 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_setProperty_6.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_setProperty_6.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("    <span class=\"pagelinks\">[First/Prev] {0}[<a href=\"{3}\">Next</a>/<a href=\"{4}\">Last</a>]</span></div>\r\n");
        int evalDoAfterBody = _jspx_th_display_setProperty_6.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_setProperty_6 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_setProperty_6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_6);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_6);
    return false;
  }

  private boolean _jspx_meth_display_setProperty_7(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  display:setProperty
    org.displaytag.tags.SetPropertyTag _jspx_th_display_setProperty_7 = (org.displaytag.tags.SetPropertyTag) _jspx_tagPool_display_setProperty_name.get(org.displaytag.tags.SetPropertyTag.class);
    _jspx_th_display_setProperty_7.setPageContext(_jspx_page_context);
    _jspx_th_display_setProperty_7.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) this ));    _jspx_th_display_setProperty_7.setName("paging.banner.last");
    int _jspx_eval_display_setProperty_7 = _jspx_th_display_setProperty_7.doStartTag();
    if (_jspx_eval_display_setProperty_7 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_setProperty_7 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_setProperty_7.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_setProperty_7.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("    <span class=\"pagelinks\">[<a href=\"{1}\">First</a>/<a href=\"{2}\">Prev</a>]{0} [Next/Last]</span></div>\r\n");
        int evalDoAfterBody = _jspx_th_display_setProperty_7.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_setProperty_7 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_setProperty_7.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_7);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_7);
    return false;
  }

  private boolean _jspx_meth_display_setProperty_8(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  display:setProperty
    org.displaytag.tags.SetPropertyTag _jspx_th_display_setProperty_8 = (org.displaytag.tags.SetPropertyTag) _jspx_tagPool_display_setProperty_name.get(org.displaytag.tags.SetPropertyTag.class);
    _jspx_th_display_setProperty_8.setPageContext(_jspx_page_context);
    _jspx_th_display_setProperty_8.setParent(new javax.servlet.jsp.tagext.TagAdapter((javax.servlet.jsp.tagext.SimpleTag) this ));    _jspx_th_display_setProperty_8.setName("paging.banner.onepage");
    int _jspx_eval_display_setProperty_8 = _jspx_th_display_setProperty_8.doStartTag();
    if (_jspx_eval_display_setProperty_8 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_display_setProperty_8 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_display_setProperty_8.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_display_setProperty_8.doInitBody();
      }
      do {
        out.write("\r\n");
        out.write("    <span class=\"pagelinks\"></span></div>\r\n");
        int evalDoAfterBody = _jspx_th_display_setProperty_8.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_display_setProperty_8 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_display_setProperty_8.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_8);
      throw new SkipPageException();
    }
    _jspx_tagPool_display_setProperty_name.reuse(_jspx_th_display_setProperty_8);
    return false;
  }
}
