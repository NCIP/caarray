Java clients to test the CaArray Remote Java API and GRID API:
--------------------------------------------------------------
1. The clients connect to array.nci.nih.gov. (If using a different
   installation of caArray, please set the right server name, jndi port
   and grid service port in build.xml.)
2. All jar dependencies including the caArray client jar are in the
   lib/directory. They are also downloadable from
   https://gforge.nci.nih.gov/frs/download.php/4065/caarray-client.zip.
3. ant targets:
     clean
     build
     run_exercise<number>_java
     run_exercise<number>_grid

Note: The output of the tests depends on certain data being available
in the caArray system you are connecting to. Most tests rely on the
following public experiment being present:
   Name: Affymetrix Experiment with CHP Data 01
   Array design: Test3.cdf
   Data files: Test3-1-121502.CHP and Test3-1-121502.CEL
The data/ directory contains these files if you need them.
