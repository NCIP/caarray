This file describes the contents of the caarray_hackathon_2008 directory.

1. SLIDES
     caarray_hackathon_2008.ppt:
       Slides for the hackathon presentation on June 24, 2008.

2. EXERCISES
     hackathon_exercises:
       3 basic exercises, plus 4 optional exercises.
       Contains source code, libraries, resources (e.g., client.wsdd) and an Ant build file.
       Also contains a README.txt that shows you how to build and run the exercises.

3. DOCUMENTATION
     docs/api/index.html:
       Javadocs.
     docs/model/:
       The caarray client model in Enterprise Architect format.
