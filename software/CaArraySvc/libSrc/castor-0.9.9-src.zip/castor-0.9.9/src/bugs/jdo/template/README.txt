bug number: 1820
description: Bug report template for castor jdo.
castor: version 0.9.6 or CVS of 2005-03-31 13:44
database: MySQL version 4.1
driver: mysql-connector-java-3.0.16-ga-bin.jar
