/*
 * This class was automatically generated with 
 * <a href="http://castor.exolab.org">Castor 0.9.4</a>, using an
 * XML Schema.
 * $Id: PathType.java,v 1.2 2005/03/05 13:41:43 mfuchs Exp $
 */

package org.exolab.castor.builder.binding;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/


/**
 * 
 *                  This type represents an easy path to access an
 * element or an attribute
 *                  inside a schema. It is a direct restriction of
 * the XPath specification.
 *              
 * 
 * @version $Revision: 1.2 $ $Date: 2005/03/05 13:41:43 $
**/
public class PathType implements java.io.Serializable {


      //----------------/
     //- Constructors -/
    //----------------/

    public PathType() {
        super();
    } //-- org.exolab.castor.builder.binding.PathType()

}
