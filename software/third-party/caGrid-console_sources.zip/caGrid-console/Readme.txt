

caGrid Console



------------------------------------------------------------------------

Introduction
------------------------------------------------------------------------
caGrid Console overloads the behavior of the default AxisServlet
used by the globus toolkit to provide a richer UI for the Globus
toolkit. It is also designed to handle caGrid specific information.



------------------------------------------------------------------------

Deployment
------------------------------------------------------------------------

1. Deploy Globus in Tomcat/JBoss. If you already have caGrid/Globus
deployed as a web application in Tomcat/JBoss, you can skit to step #2

Here are instructions to deploy Globus into Tomcat and Jboss

Tomcat ->http://www.cagrid.org/wiki/CaGrid:ConfigureTomcat

JBoss ->http://www.cagrid.org/wiki/CaGrid:How-To:DeployGlobusToJBoss


2. Download the source code for caGrid Console project. For eg.

svn checkout http://cagrid-widgets.googlecode.com/svn/trunk/caGrid\ console cagrid-console

This will checkout the caGrid console project into ./cagrid-console directory. We will
refer this directory as $CAGRID_CONSOLE_HOME


3. Set your CATALINA_HOME or JBOSS_HOME environment variable



4. Run the 'deployTomcat' or 'deployJBoss' ant target
to deploy the caGrid console into Tomcat or JBoss. For eg.

ant -f $CAGRID_CONSOLE_HOME/build.xml deployTomcat


5. Start Tomcat/JBOSS

6. Go to http://localhost:8080/wsrf/cagrid
to view the caGrid Console

Note: Your URL:port can vary for your deployment of JBoss/Tomcat






