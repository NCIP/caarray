package gov.nih.nci.cagrid.console;

import java.io.PrintWriter;
import java.io.Writer;

/**
 * User: kherm
 *
 * @author kherm manav.kher@semanticbits.com
 */
public class HTMLWriter extends PrintWriter {


    public HTMLWriter(Writer writer) {
        super(writer);
    }


    public void startSpan(String styleClass) {
        append("<span");
        if (styleClass != null)
            append(" class=\"" + styleClass + "\"");
        append(">");
    }

    public void endSpan() {
        append("</span>");
    }


    public void startDiv(String styleClass) {
        append("<div");
        if (styleClass != null)
            append(" class=\"" + styleClass + "\"");
        append(">");
    }


    public void endDiv() {
        append("</div>");
    }

    public void startList() {
        append("<ul>");
    }

    public void endList() {
        append("</ul>");
    }

    public void listItem(String text) {
        append("<li>");
        append(text);
        append("</li>");
    }

    public void listItem(String key, String value) {
        append("<li>");
        bold(key);
        append(": ");
        append(value);
        append("</li>");
    }

    public void append(boolean b) {
        append(Boolean.toString(b));
    }

    public void h2(String text) {
        append("<h2>");
        append(text);
        append("</h2>");
    }

    public void h3(String text) {
        append("<h3>");
        append(text);
        append("</h3>");
    }


    public void bold(String text) {
        append("<b>");
        append(text);
        append("</b>");
    }

    public void br() {
        append("<br/>");
    }

    public String href(String link, String linkText) {
        return "<a href=\"" + link + "\">" + linkText + "</a>";
    }

    public void row(String key, String value) {

        startDiv(null);
        bold(key + ": ");
        if (value != null)
            append(value);
        endDiv();
    }

    public void h4(String text) {
        append("<h4>");
        append(text);
        append("</h4>");
    }
}
