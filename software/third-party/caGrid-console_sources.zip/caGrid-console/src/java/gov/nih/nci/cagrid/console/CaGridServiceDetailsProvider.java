package gov.nih.nci.cagrid.console;

import gov.nih.nci.cagrid.metadata.ServiceMetadata;
import gov.nih.nci.cagrid.metadata.common.PointOfContact;
import gov.nih.nci.cagrid.metadata.common.ResearchCenter;
import gov.nih.nci.cagrid.metadata.service.Service;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.description.ServiceDesc;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.globus.mds.servicegroup.client.ServiceGroupRegistrationParameters;
import org.globus.wsrf.Constants;
import org.globus.wsrf.config.ContainerConfig;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * User: kherm
 *
 * @author kherm manav.kher@semanticbits.com
 */
public class CaGridServiceDetailsProvider implements ServiceDetailsProvider {

    protected static Log LOG = LogFactory.getLog(ServiceDetailsProvider.class.getName());

    public void getDetails(HTMLWriter html, ServiceDesc sd) {
        try {
            String name = sd.getName();
            String jndiName = Constants.JNDI_SERVICES_BASE_NAME + name + "/configuration";

            html.h2("Operations: ");
            html.startDiv("serviceDetails");
            ArrayList operations = sd.getOperations();
            if (!operations.isEmpty()) {
                html.startList();
                for (Iterator it = operations.iterator(); it.hasNext();) {
                    OperationDesc desc = (OperationDesc) it.next();
                    html.listItem(desc.getName());
                }
                html.endList();
            }

            html.endDiv();

            Context initialContext = new InitialContext();
            Object configuration = null;
            try {
                configuration = initialContext.lookup(jndiName);
            } catch (NamingException e) {
                //name not found
                return;
            }

            html.h2("Service Registration Details");
            html.startDiv("serviceDetails");

            if (configuration.getClass().getMethod("shouldPerformRegistration") != null) {
                boolean performRegistration = (Boolean) configuration.getClass().getMethod("shouldPerformRegistration").invoke(configuration, (Object[])null);

                html.row("Perform Registration", Boolean.toString(performRegistration));

                String registrationFileName = (String) configuration.getClass().getMethod("getRegistrationTemplateFile").invoke(configuration,(Object[]) null);
                File registrationFile = new File(ContainerConfig.getBaseDirectory() + File.separator
                        + registrationFileName);

                if (registrationFile.exists() && registrationFile.canRead()) {

                    try {
                        ServiceGroupRegistrationParameters params = Utils.deserializeDocument(registrationFile.getAbsolutePath(),
                                ServiceGroupRegistrationParameters.class);
                        String registrantEpr = params.getServiceGroupEPR().getAddress().toString();

                        if (registrantEpr != null) {
                            html.row("Index Service", registrantEpr);
                        }
                    } catch (Exception e) {
                        LOG.error("Problem reading registration file " + e.getMessage());
                    }
                } else {
                    html.h3("Could not read registration file at " + registrationFile.getAbsolutePath());
                }
            }
            html.endDiv();


            html.h2("Service Metadata");
            html.startDiv("serviceDetails");

            try {
                String _sMetaFileName = (String) configuration.getClass().getMethod("getServiceMetadataFile").invoke(configuration, (Object[])null);


                ServiceMetadata _smeta = Utils.deserializeDocument(ContainerConfig.getBaseDirectory() + File.separator
                        + _sMetaFileName, ServiceMetadata.class);
                // Just to throw any possible exception
                _smeta.getServiceDescription().getService();

                appendServiceMetadata(_smeta, html);
            } catch (IOException e) {
                LOG.error("Problem reading Service metadata file ", e);
                html.bold("Could not load Service Metadata");
            }
            html.endDiv();

        } catch (Exception e) {
            LOG.error("Problem reading Service metadata for service ", e);
        }
    }

    private void appendServiceMetadata(ServiceMetadata smeta, HTMLWriter html) {
        html.startDiv(null);

        Service _svc = smeta.getServiceDescription().getService();

        html.startDiv(null);
        html.h3("Service Details");
        try {
            html.row("Name", _svc.getName());
            html.row("Description", _svc.getDescription());
            html.row("Version", _svc.getVersion());
            if (_svc.getCaDSRRegistration() != null) {
                html.h3("CaDSR Registration");
                html.row("Registration Status", _svc.getCaDSRRegistration().getRegistrationStatus());
                html.row("Workflow Status", _svc.getCaDSRRegistration().getWorkflowStatus());
            }
        } catch (Exception e) {
            html.bold("Could not find Service Details.");
        }
        html.endDiv();

        if (_svc.getPointOfContactCollection() != null && _svc.getPointOfContactCollection().getPointOfContact() != null)
            appendPointofContacts(_svc.getPointOfContactCollection().getPointOfContact(), html);

        appendResearchCenterInfo(smeta, html);
        html.endDiv();
    }

    private void appendResearchCenterInfo(ServiceMetadata smeta, HTMLWriter html) {
        html.startDiv(null);
        html.h3("Research Center Information");

        try {
            ResearchCenter _center = smeta.getHostingResearchCenter().getResearchCenter();
            html.row("Short Name", _center.getShortName());
            html.row("Display Name", _center.getDisplayName());
            if (_center.getResearchCenterDescription() != null) {
                html.row("Description", _center.getResearchCenterDescription().getDescription());
                html.row("Homepage URL", _center.getResearchCenterDescription().getHomepageURL());
            }
            html.endDiv();

            if (_center.getAddress() != null) {
                html.startDiv(null);
                html.h4("Address");
                html.row("Street 1", _center.getAddress().getStreet1());
                html.row("Street 2", _center.getAddress().getStreet2());
                html.row("Locality", _center.getAddress().getLocality());
                html.row("State/Province", _center.getAddress().getStateProvince());
                html.row("Postal Code", _center.getAddress().getPostalCode());
                html.row("Country", _center.getAddress().getCountry());
                html.endDiv();

                if (_center.getPointOfContactCollection() != null && _center.getPointOfContactCollection().getPointOfContact() != null)
                    appendPointofContacts(_center.getPointOfContactCollection().getPointOfContact(), html);
            } else {
                html.bold("Research Center address not provided.");
            }
        } catch (Exception e) {
            //no RC found
            html.bold("Could not find Research Center information.");
        }
    }

    private void appendPointofContacts(PointOfContact[] pocs, HTMLWriter html) {
        html.startDiv(null);
        for (PointOfContact _poc : pocs) {
            html.h4("Point of Contact");
            html.row("First name", _poc.getFirstName());
            html.row("Last Name", _poc.getLastName());
            html.row("Affiliation", _poc.getAffiliation());
            html.row("Role", _poc.getRole());
            html.row("Email", _poc.getEmail());
            html.row("Phone Number", _poc.getPhoneNumber());
        }
        html.endDiv();

    }


}



