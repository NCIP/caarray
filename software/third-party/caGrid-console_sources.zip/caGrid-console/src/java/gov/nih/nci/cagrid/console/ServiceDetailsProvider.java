package gov.nih.nci.cagrid.console;

import org.apache.axis.description.ServiceDesc;

/**
 * User: kherm
 *
 * @author kherm manav.kher@semanticbits.com
 */
public interface ServiceDetailsProvider {

    public void getDetails(HTMLWriter writer, ServiceDesc name);
}
