package gov.nih.nci.cagrid.console;

import java.io.*;
import java.util.Calendar;

/**
 * User: kherm
 *
 * @author kherm manav.kher@semanticbits.com
 */
public class Utils {

    public static final String CLIENT_CONFIG_WSDD = "client-config.wsdd";

    public static String getResourceAsString(String resource) throws IOException {

        InputStream _is = Utils.class.getClassLoader().getResourceAsStream(resource);
        return getStreamAsString(_is);

    }

    public static String getStreamAsString(InputStream is) throws IOException {
        byte[] _buff = new byte[1024];
        ByteArrayOutputStream _baos = new ByteArrayOutputStream(1024);

        while (true) {
            int length = is.read(_buff);

            if (length == -1) {
                break;
            }
            _baos.write(_buff, 0, length);
        }
        return _baos.toString();
    }


    public static String getSystemTime() {
        return Calendar.getInstance().getTime().toString();
    }

    public static <T> T deserializeDocument(String file, Class<T> tClass)
            throws Exception {
        File inputDoc = new File(file);

        if (inputDoc.exists() && inputDoc.canRead()) {
            FileReader xmlSource = new FileReader(inputDoc);

            T returnT = null;
            try {
                returnT = (T) gov.nih.nci.cagrid.common.
                        Utils.deserializeObject(xmlSource,
                        tClass,
                        Utils.class.getResourceAsStream(CLIENT_CONFIG_WSDD));
            } catch (Exception e) {
                throw new IOException("Could not load Semantic Metadata" + e.getMessage());
            }

            return returnT;
        } else
            throw new FileNotFoundException("Semantic metadata file not found or is not readable:" + inputDoc.getAbsolutePath());
    }
}
