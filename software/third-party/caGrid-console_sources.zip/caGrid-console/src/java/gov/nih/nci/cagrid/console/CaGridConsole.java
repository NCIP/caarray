package gov.nih.nci.cagrid.console;

import org.apache.axis.AxisEngine;
import org.apache.axis.AxisFault;
import org.apache.axis.AxisProperties;
import org.apache.axis.ConfigurationException;
import org.apache.axis.description.ServiceDesc;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

/**
 * User: kherm
 *
 * @author kherm manav.kher@semanticbits.com
 */
public class CaGridConsole extends org.globus.wsrf.container.AxisServlet {
    protected static Log LOG = LogFactory.getLog(CaGridConsole.class.getName());


    ServiceDetailsProvider provider;
    public final String INIT_PROPERTY_CAGRID_CONSOLE_PATH = "cagrid.console.path";
    public final String INIT_PROPERTY_CAGRID_CONSOLE_PATH_VALUE = "/cagrid/";

    public CaGridConsole() {
        super();
        // needs to be put in a configurable (dependency injection)
        provider = new CaGridServiceDetailsProvider();
        AxisProperties.setProperty(INIT_PROPERTY_CAGRID_CONSOLE_PATH_VALUE, "/cagrid/");
    }

    @Override
    protected void reportAvailableServices(HttpServletResponse response, PrintWriter pw, HttpServletRequest request) throws ConfigurationException, AxisFault {

        AxisEngine engine = getEngine();
        response.setContentType("text/html; charset=utf-8");

        HTMLWriter html = new HTMLWriter(pw);
        writeHeader(html);

        html.startDiv("content");

        Iterator i;
        try {
            i = engine.getConfig().getDeployedServices();
            writeGlobalOptions(html);

        } catch (ConfigurationException configException) {
            if (configException.getContainedException() instanceof AxisFault) {
                throw (AxisFault) configException.getContainedException();
            } else {
                throw configException;
            }
        }

        html.h2("Service List");
        html.startList();

        while (i.hasNext()) {
            ServiceDesc sd = (ServiceDesc) i.next();

            html.startDiv("service");
            String name = sd.getName();

            html.startDiv("serviceName");
            html.listItem(name);
            html.endDiv();
            String endpointURL = sd.getEndpointURL();
            String wsdlURL = (endpointURL == null) ? getWebappBase(request) + getOption(getServletConfig().getServletContext(), INIT_PROPERTY_SERVICES_PATH, "/services/") + name :
                    endpointURL;

            html.startDiv("serviceDetails");
            html.row("Service URL", wsdlURL);
            html.row("Service WSDL", html.href(wsdlURL + "?wsdl", "WSDL"));

            SOAPService _service = engine.getService(name);
            html.row("Service Running", Boolean.toString(_service.isRunning()));

            String baseURL = (endpointURL == null) ? getWebappBase(request) + getOption(getServletConfig().getServletContext(), INIT_PROPERTY_CAGRID_CONSOLE_PATH, INIT_PROPERTY_CAGRID_CONSOLE_PATH_VALUE) + name :
                    endpointURL;

            html.append(html.href(baseURL, "More Details"));
            html.endDiv();

            html.endDiv();
        } //end for loop

        html.endList();
        html.endDiv();

    }

    @Override
    protected void reportServiceInfo(HttpServletResponse response, PrintWriter pw, SOAPService soapService, String s) {
        response.setContentType("text/html; charset=utf-8");

        HTMLWriter html = new HTMLWriter(pw);
        writeHeader(html);
        html.startDiv("content");
        html.h2("Service Overview");

        ServiceDesc sd = soapService.getServiceDescription();

        html.startDiv("serviceDetails");
        html.row("Service Name", sd.getName());
        html.endDiv();

        provider.getDetails(html, sd);
        html.endDiv();
    }


    protected void writeGlobalOptions(HTMLWriter html) {
        try {
            html.startDiv("service");
            html.h2("Global Options");
            html.startList();

            html.listItem("Publishing Hostname", Boolean.toString(getEngine().getConfig().getGlobalOptions().containsKey("publishHostName")));

            String logicalHost = (String) getEngine().getConfig().getGlobalOptions().get("logicalHost");
            if (logicalHost != null)
                html.listItem("LogicalHost specified", logicalHost);
            else
                html.listItem("LogicalHost specified", "No");

            try {
                html.listItem("System Time", Utils.getSystemTime());
            } catch (Exception e) {
                LOG.error("Error writing Global Options", e);
            }
            html.endList();
            html.endDiv();
        } catch (ConfigurationException e) {
            LOG.error("Error writing Global Options", e);
        } catch (AxisFault axisFault) {
            LOG.error("Error writing Global Options", axisFault);
        }

    }


    protected void writeStylesheet(PrintWriter pw) {
        try {
            pw.append(Utils.getResourceAsString("cagrid-console.css"));
        } catch (IOException e) {

            LOG.error("Error loading style sheet", e);
        }
    }

    protected void writeHeader(HTMLWriter html) {
        writeStylesheet(html);

        html.startDiv("header");
        html.append("caGrid Console");
        html.endDiv();
    }
}
