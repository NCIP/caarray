package gov.nih.nci.cagrid.console;

import junit.framework.TestCase;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * User: kherm
 *
 * @author kherm manav.kher@semanticbits.com
 */
public class CaGridConsoleTest extends TestCase {

    public void testGetStyle(){
        CaGridConsole console = new CaGridConsole();
        StringWriter buff = new StringWriter();
        assertFalse(buff.toString().length()>0);


        PrintWriter pw = new PrintWriter(buff);
        console.writeStylesheet(pw);
        assertTrue(buff.toString().length()>0);

    }


}
