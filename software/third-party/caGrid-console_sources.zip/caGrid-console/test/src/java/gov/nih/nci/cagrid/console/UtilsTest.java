package gov.nih.nci.cagrid.console;

import junit.framework.TestCase;
import gov.nih.nci.cagrid.metadata.ServiceMetadata;

import java.io.File;

import org.globus.mds.servicegroup.client.ServiceGroupRegistrationParameters;

/**
 * User: kherm
 *
 * @author kherm manav.kher@semanticbits.com
 */
public class UtilsTest extends TestCase {

    public void testGetServiceMetadata(){

        try {
            ServiceMetadata  _meta = Utils.deserializeDocument("test/data/serviceMetadata.xml",ServiceMetadata.class);
            assertNotNull(_meta);

        } catch (Exception e) {
            fail("Could not load metadata" + e.getMessage());
        }

    }


    public void testRegistrationInfo(){

        try {
            ServiceGroupRegistrationParameters  _reg = Utils.deserializeDocument("test/data/registration.xml",ServiceGroupRegistrationParameters.class);
            assertNotNull(_reg);
            assertNotNull(_reg.getServiceGroupEPR().getAddress().toString());
            assertEquals("http://index-service",_reg.getServiceGroupEPR().getAddress().toString());

        } catch (Exception e) {
            fail("Could not load metadata" + e.getMessage());
        }
    }


    public void testGetResourceAsString(){
        try{
            Utils.getResourceAsString("cagrid-console.css");
        } catch (Exception e) {
            fail("Could not load metadata" + e.getMessage());
        }

    }
}
