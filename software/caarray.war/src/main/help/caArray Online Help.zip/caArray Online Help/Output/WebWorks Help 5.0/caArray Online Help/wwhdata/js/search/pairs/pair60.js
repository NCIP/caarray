function FileData_Pairs(x)
{
x.t("describes","processes");
x.t("caarray","repository");
x.t("caarray","section");
x.t("caarray","extracting");
x.t("repository","topics");
x.t("processes","extracting");
x.t("programmatically","api");
x.t("section","describes");
x.t("section","include");
x.t("include","downloading");
x.t("extracting","data");
x.t("data","caarray");
x.t("data","programmatically");
x.t("topics","section");
x.t("downloading","data");
}
