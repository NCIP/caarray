function  WWHBookData_MatchTopic(P)
{
var C=null;
if(P=="login_help")C="Getting%20Started%20caArray.3.6.html#1140027";
if(P=="caArray:Data_Portal_page;Data_portal_page")C="Getting%20Started%20caArray.3.6.html#1124014";
if(P=="caArray:loginh")C="Getting%20Started%20caArray.3.6.html#1124014";
if(P=="register_user_help")C="Getting%20Started%20caArray.3.7.html#1125266";
if(P=="add_group_help")C="User%20Account%20Mgt.8.5.html#1139979";
if(P=="group_details_help")C="User%20Account%20Mgt.8.6.html#1077437";
if(P=="modify_group_details_help")C="User%20Account%20Mgt.8.7.html#1087125";
return C;
}
