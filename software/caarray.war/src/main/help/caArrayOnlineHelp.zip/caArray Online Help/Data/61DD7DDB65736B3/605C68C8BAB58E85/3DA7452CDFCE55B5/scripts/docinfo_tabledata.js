function WWLoadDocInfoData()
{
  WWDocInfo.fAddProperty('N1227153', 'cellSpacing', '2');
  WWDocInfo.fAddProperty('N1223062', 'cellSpacing', '2');
  WWDocInfo.fAddProperty('N1223481', 'cellSpacing', '2');
}
