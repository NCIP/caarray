function FileData_Pairs(x)
{
x.t("questions","user");
x.t("questions","initial");
x.t("user","account");
x.t("account","management");
x.t("initial","questions");
x.t("management","initial");
}
