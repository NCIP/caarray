function FileData_Pairs(x)
{
x.t("example","body");
x.t("text","example");
x.t("second-level","heading");
x.t("body","text");
x.t("heading","second-level");
x.t("heading","body");
x.t("heading","heading");
x.t("heading","submitting");
x.t("heading","first-level");
x.t("submitting","data");
x.t("experiment","heading");
x.t("data","experiment");
x.t("first-level","heading");
}
