function FileData_Pairs(x)
{
x.t("example","body");
x.t("caarray","heading");
x.t("text","example");
x.t("second-level","heading");
x.t("body","text");
x.t("heading","second-level");
x.t("heading","body");
x.t("heading","heading");
x.t("heading","extracting");
x.t("heading","first-level");
x.t("extracting","data");
x.t("data","caarray");
x.t("first-level","heading");
}
